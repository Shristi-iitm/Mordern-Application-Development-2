from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__, template_folder="templates")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///week7_database.sqlite3"
db=SQLAlchemy(app)
app.app_context().push()

class Student(db.Model):
    student_id=db.Column(db.Integer, primary_key=True)
    roll_number=db.Column(db.String, unique=True, nullable=False)
    first_name=db.Column(db.String, nullable=False)
    last_name=db.Column(db.String)
    subs=db.relationship("Course",backref="stud", secondary="enrollments")

class Course(db.Model):
    course_id=db.Column(db.Integer, primary_key=True)
    course_code=db.Column(db.String, unique=True, nullable=False)
    course_name=db.Column(db.String, nullable=False)
    course_description=db.Column(db.String)

class Enrollments(db.Model):
    enrollment_id=db.Column(db.Integer, primary_key=True)
    estudent_id=db.Column(db.Integer, db.ForeignKey("student.student_id"), nullable=False)
    ecourse_id=db.Column(db.Integer, db.ForeignKey("course.course_id"), nullable=False)

@app.route('/', methods=['GET'])
def home():
    a=Student.query.all()
    cond=a==[]
    l=list(zip(range(1,len(a)+1),a))
    return render_template("student_index.html",cond=cond,l=l)
#-----------------------------------------------------------------------------------------------------------------------
@app.route('/student/create', methods=['GET','POST'])
def add_stud():
    if request.method=="GET":
        return render_template("add_student.html")
    elif request.method=="POST":
        roll=request.form.get('roll')
        first=request.form.get('f_name')
        last=request.form.get('l_name')
        if Student.query.filter_by(roll_number=roll)==[]:
            msg="Student already exists. Please use different Roll Number!!"
            return render_template("error.html", message=msg,url="/")
        s=Student(roll_number=roll,first_name=first, last_name=last)
        db.session.add(s)
        db.session.commit()
        return redirect(url_for('home'))

#---------------------------------------------------------------------------------------------------------------------------

@app.route('/student/<int:s_i>/update', methods=["GET","POST"])
def update_student(s_i):
    if request.method == "GET":
        a=Student.query.filter_by(student_id=s_i).first()
        c=Course.query.all()
        return render_template("update_student.html",a=a,c=c)
    elif request.method == "POST":
        course=request.form.get('course')
        stud=Student.query.filter_by(student_id=s_i).first()
        stud.first_name=request.form.get('f_name')
        stud.last_name=request.form.get('l_name')
        try:
            enroll=Enrollments(estudent_id=s_i,ecourse_id=course)
            db.session.add(enroll)
            db.session.commit()
        finally:
            return redirect(url_for('home'))

#---------------------------------------------------------------------------------------------------------------------------

@app.route('/student/<int:s_i>/delete', methods=["GET"])
def remove_student(s_i):
    if request.method=="GET":
        stud=Student.query.filter_by(student_id=s_i).first()
        db.session.delete(stud)
        to_del=Enrollments.query.filter_by(estudent_id=s_i).all()
        for i in to_del:
            db.session.delete(i)
        db.session.commit()
    return redirect(url_for('home'))
#--------------------------------------------------------------------------------------------------------
@app.route('/student/<int:s_i>')
def roll(s_i):
    a=Student.query.filter_by(student_id=s_i).first()
    sub=list(zip(range(1,len(a.subs)+1),a.subs))
    return render_template("roll_no.html",a=a,sub=sub)
#----------------------------------------------------------------------------------------------------------------------
@app.route("/student/<int:s_id>/withdraw/<int:c_id>")
def withdraw(s_id,c_id):
    enroll=Enrollments.query.filter_by(estudent_id=s_id,ecourse_id=c_id).first()
    db.session.delete(enroll)
    db.session.commit()
    return redirect(url_for("home"))
#------------------------------------------------------------------------------------------------------------------
@app.route("/courses")
def courses():
    c=Course.query.all()
    return render_template("course_index.html", cond=c==[], courses=c)
#---------------------------------------------------------------------------------------------------------------------
@app.route("/course/create", methods=["GET","POST"])
def create_course():
    if request.method=="GET":
        return render_template("add_course.html")
    code=request.form.get("code")
    name=request.form.get("c_name")
    c_d=request.form.get("desc", None)
    if Course.query.filter_by(course_code=code)==[]:
        msg="Course already exits. Please create a different course!!"
        return render_template("error.html", message=msg, url="/courses")
    new_course=Course(course_code=code, course_name=name,course_description=c_d)
    db.session.add(new_course)
    db.session.commit()
    return redirect(url_for('courses'))
#---------------------------------------------------------------------------------------------------------------------
@app.route("/course/<int:c_id>/update", methods=["GET","POST"])
def update_course(c_id):
    c=Course.query.filter_by(course_id=c_id).first()
    if request.method=="GET":
        return render_template("update_course.html", course=c)
    c.course_name=request.form.get("c_name")
    c.course_description=request.form.get("desc")
    db.session.commit()
    return redirect(url_for("courses"))
#---------------------------------------------------------------------------------------------------------------------
@app.route("/course/<int:c_id>/delete")
def remove_course(c_id):
    c=Course.query.filter_by(course_id=c_id).first()
    for i in Enrollments.query.filter_by(ecourse_id=c_id).all():
        db.session.delete(i)
    db.session.delete(c)
    db.session.commit()
    return redirect(url_for("courses"))
#---------------------------------------------------------------------------------------------------------------------
@app.route("/course/<int:c_id>")
def course_list(c_id):
    c=Course.query.filter_by(course_id=c_id).first()
    return render_template("course_list.html",c=c)
#---------------------------------------------------------------------------------------------------------------------
if __name__ =='__main__':
    app.run(port=5000,debug=True)